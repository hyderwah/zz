import {NgModule} from '@angular/core';
import {HttpModule} from '@angular/http';
import {CommonModule} from '@angular/common';
import { DataTableModule } from 'angular2-datatable';
//import { NG2DataTableModule } from "angular2-datatable-pagination";
import {BrowserModule} from '@angular/platform-browser';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {RouterModule} from '@angular/router';
import {ModalModule} from 'angular2-modal';
import {BootstrapModalModule} from 'angular2-modal/plugins/bootstrap';
import {UserLoginComponent} from './userLogin/userLogin.component';
import {AccountRouting} from './account.routes';
import {AuthService} from './services/auth.service';

@NgModule({
  imports: [
    AccountRouting,
    HttpModule,
    CommonModule,
    DataTableModule,
    //NG2DataTableModule,
    FormsModule,
    ReactiveFormsModule,
    ModalModule.forRoot(),
    BootstrapModalModule
  ],
  declarations: [
    UserLoginComponent
    // AffiliateRegistrationComponent,
    // ForgotPasswordComponent
  ],
  providers: [
    // RouterOutletMap,
    // AccountService
    AuthService
  ],
  entryComponents: [
    //  ForgotPasswordComponent
  ]


})
export class AccountModule {
}

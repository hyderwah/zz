import {Routes, RouterModule} from '@angular/router';
import {ModuleWithProviders} from '@angular/core';
import { UserLoginComponent } from './userLogin/userLogin.component';

export const AccountRoutes: Routes = [
  {
    path: 'login',
    component: UserLoginComponent
  }
];

export const AccountRouting: ModuleWithProviders = RouterModule.forChild(AccountRoutes);


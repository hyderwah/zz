import {Injectable, OnInit} from '@angular/core';
import {Observable} from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';
import {Http, Response, Headers, RequestOptions, URLSearchParams, RequestMethod, Jsonp} from '@angular/http';
import {AppService} from '../../app.service';
import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';

@Injectable()
export class AuthService implements OnInit {

  private actionUrl: string;

  ngOnInit(): void {
    throw new Error('Method not implemented.');
  }

  constructor(private http: Http, private appService: AppService, private jsonp: Jsonp, private router: Router) {
    this.actionUrl = this.appService.apiRootUrl.loginApiUrl;
  }

  login(username: string, password: string) {
    const headers = new Headers();
    headers.append('content-type', 'application/json');
    const body = JSON.stringify({ username: username, password: password });
    return this.http.post(`${this.actionUrl}login`, body, { headers: headers })
      .map((response: Response) => <any>response.json());




    //return this.http.post(`${this.actionUrl}login`, body, headers)
    //  .map(user => {
    //    // login successful if there's a jwt token in the response
    //    // if (user && user.token) {
    //      // store user details and jwt token in local storage to keep user logged in between page refreshes
    //      localStorage.setItem('currentUser', JSON.stringify(user));
    //      // }

    //    return user;
    //  });
  }

  logout() {
    // remove user from local storage to log user out
    localStorage.removeItem('currentUser');
    this.router.navigate(['/login']);
  }

}

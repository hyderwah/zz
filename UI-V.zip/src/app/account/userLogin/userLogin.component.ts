import { Component, OnInit, ViewContainerRef, Optional, ViewEncapsulation } from '@angular/core';
import { AuthService } from '../services/auth.service';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
//import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'vod-login',
  templateUrl: './userLogin.component.html',
  styleUrls: ['./userLogin.component.css']
})
export class UserLoginComponent implements OnInit {
  public myForm: FormGroup;
  constructor(public authService: AuthService, private fb: FormBuilder, public router: Router) {
    this.fb = new FormBuilder();
  }

  ngOnInit() {
    this.myForm = this.fb.group({
      userName: ['', [<any>Validators.required]],
      password: ['', [<any>Validators.required]],
      rememberMe: [false, []]
    });
  }


  keyDownFunction(event, model: any) {
    if (event.keyCode == 13) {
      this.onLoginClick(model, true);
    }
  }

  onLoginClick(model: any, isValid: boolean): void {
    this.authService.login(model.userName, model.password).subscribe(
      data => {
        if (data) {
          //this.toastr.success('Hello world!', 'Toastr fun!');
          localStorage.setItem('currentUser', JSON.stringify(data));
          this.router.navigate(['/vod/affiliatemapping']);
        }
        else {
          alert('Login failed. Please try again');
        }
      },
      error => {
        alert(error);
      }
    );
  }
}


import { Component } from '@angular/core';
import { AuthService } from '../account/services/auth.service';
import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';

@Component({
  selector: 'vod-master',
  templateUrl: './vod.component.html'
})
export class VodComponent {
  // title = 'Angular: Getting Started';

  public currentUser: any;


  constructor(public authService: AuthService, public router: Router) {
    this.currentUser = JSON.parse(localStorage.getItem('currentUser'));


  }

  logoutRoute = () => {
    this.authService.logout();
  }

}


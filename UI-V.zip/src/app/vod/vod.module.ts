import {BrowserModule} from '@angular/platform-browser';
import {NgModule, CUSTOM_ELEMENTS_SCHEMA, APP_INITIALIZER} from '@angular/core';
import {HttpClientModule} from '@angular/common/http';
import {HttpModule, JsonpModule} from '@angular/http';
import {RouterModule} from '@angular/router';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import { DataTableModule, PageEvent } from 'angular2-datatable';
//import { NG2DataTableModule } from "angular2-datatable-pagination";
import {HashLocationStrategy, LocationStrategy} from '@angular/common';
import {AuthGuard} from '../guard/index';

// import {ModalModule} from 'ngx-modialog';
// import {BootstrapModalModule} from 'ngx-modialog/plugins/bootstrap';

import {ModalModule} from 'angular2-modal';
import {BootstrapModalModule} from 'angular2-modal/plugins/bootstrap';

import {DataFilterPipe} from './affiliate/filter/table.pipe';
import {OrderByPipe} from './affiliate/filter/orderby.pipe';

import {VodComponent} from './vod.component';
import {VodRouting} from './vod.routes';

import {AffiliateService} from './affiliate/services/Affiliate.service';

import {AddAffiliateChannelComponent} from './affiliate/affiliatechannel/AddAffiliateChannel.component';
import {AffiliateChannelComponent} from './affiliate/affiliatechannel/AffiliateChannel.component';
import {EditAffiliateChannelComponent} from './affiliate/affiliatechannel/EditAffiliateChannel.component';

import {AddAffiliateContentRerouteComponent} from './affiliate/affiliatecontentreroute/AddAffiliateContentReroute.component';
import {AffiliateContentRerouteComponent} from './affiliate/affiliatecontentreroute/AffiliateContentReroute.component';
import {EditAffiliateContentRerouteComponent} from './affiliate/affiliatecontentreroute/EditAffiliateContentReroute.component';

import {AddAffiliateMappingComponent} from './affiliate/affiliatemapping/AddAffiliateMapping.component';
import {AffiliateMappingComponent} from './affiliate/affiliatemapping/AffiliateMapping.component';
import {EditAffiliateMappingComponent} from './affiliate/affiliatemapping/EditAffiliateMapping.component';

import {ConfirmDeleteComponent} from './affiliate/shared/ConfirmDelete.component';

@NgModule({
  declarations: [
    DataFilterPipe,
    OrderByPipe,
    VodComponent,
    AddAffiliateChannelComponent,
    AffiliateChannelComponent,
    EditAffiliateChannelComponent,
    AddAffiliateContentRerouteComponent,
    AffiliateContentRerouteComponent,
    EditAffiliateContentRerouteComponent,
    AddAffiliateMappingComponent,
    AffiliateMappingComponent,
    EditAffiliateMappingComponent,
    ConfirmDeleteComponent
  ],
  imports: [
    VodRouting,
    BrowserModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    DataTableModule,
    //NG2DataTableModule,
    HttpModule,
    JsonpModule,
    ModalModule.forRoot(),
    BootstrapModalModule
  ],
  providers: [
    // RouterOutletMap,
    AuthGuard,
    AffiliateService,
    {provide: LocationStrategy, useClass: HashLocationStrategy}
  ],
  entryComponents: [AddAffiliateMappingComponent, EditAffiliateMappingComponent,
    AddAffiliateChannelComponent, EditAffiliateChannelComponent,
    AddAffiliateContentRerouteComponent, EditAffiliateContentRerouteComponent,
    ConfirmDeleteComponent
  ]
})

export class VodModule {}


import {Routes, RouterModule} from '@angular/router';
import {ModuleWithProviders} from '@angular/core';

import {VodComponent} from './vod.component';
import {AffiliateChannelComponent} from './affiliate/affiliatechannel/AffiliateChannel.component';
import {AffiliateContentRerouteComponent} from './affiliate/affiliatecontentreroute/AffiliateContentReroute.component';
import {AffiliateMappingComponent} from './affiliate/affiliatemapping/AffiliateMapping.component';
import {AuthGuard} from '../guard/index';

export const VodRoutes: Routes = [
  {
    path: '',
    component: VodComponent,
    canActivate: [AuthGuard],
    children: [
      {path: 'vod/affiliatemapping', component: AffiliateMappingComponent},
      {path: 'vod/affiliatechannel', component: AffiliateChannelComponent},
      {path: 'vod/affiliatechannel/:existingAlias', component: AffiliateChannelComponent},
      {path: 'vod/affiliatecontentreroute', component: AffiliateContentRerouteComponent},
      {
        path: 'vod/affiliatecontentreroute/:affiliateChannelId',
        component: AffiliateContentRerouteComponent
      },
      // {path: '', redirectTo: 'vod/affiliatechannel', pathMatch: 'full'},
      // {path: '**', redirectTo: 'vod/affiliatechannel', pathMatch: 'full'}
    ]
  }
];

export const VodRouting: ModuleWithProviders = RouterModule.forChild(VodRoutes);



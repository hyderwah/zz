﻿import {Component, OnInit, ViewContainerRef, ViewEncapsulation, ViewChild} from '@angular/core';
import {AffiliateService} from '../services/Affiliate.service';
import {AddAffiliateMappingComponent, AddAffiliateMappingContainerWindow} from './AddAffiliateMapping.component';
import {EditAffiliateMappingComponent, EditAffiliateMappingContainerWindow} from './EditAffiliateMapping.component';
import {overlayConfigFactory} from 'angular2-modal';
import {Modal, BSModalContext} from 'angular2-modal/plugins/bootstrap';
import {ConfirmDeleteComponent} from '../shared/ConfirmDelete.component';
import { DataTable } from 'angular2-datatable';


@Component({
  selector: 'vod-affiliate-mapping',
  templateUrl: './AffiliateMapping.component.html'
})
export class AffiliateMappingComponent implements OnInit {
  @ViewChild(DataTable) resultTable: DataTable;


  public afflist: any[] = [];
  public affListData: any[];
  public searchText: string;
  public rowsOnPage: number = 10;
  public activePage: number = 1;
  public existingAlias: any[];
  public useridParser: any[];
  public filterQuery = '';
  public sortBy = '';
  public sortOrder = 'desc';
  public currentUser: any;

  constructor(private affiliateService: AffiliateService, public modal: Modal, vcRef: ViewContainerRef) {
    this.affListData = [...this.afflist];
    this.currentUser = JSON.parse(localStorage.getItem('currentUser'));
  }

  ngOnInit(): void {
    this.getAffiliatemappings();
    this.getmvpdcountries();
    this.getParser();
  }

  getAffiliatemappings() {
    this.affiliateService.getAffiliatemappings()
      .subscribe(data => {
        this.afflist = [];
        this.afflist = data;
        this.affListData = data;
      }, error => {
        console.error(error);
      });
  }

  updateFilter(event) {
    const val = event.target.value.toLowerCase();
    this.searchText = val;
    // filter our data

    const temp = this.afflist.filter(function (d) {
      return d.mvpdAliasRequest.toLowerCase().indexOf(val) !== -1 ||
        d.ExistingAlias.toLowerCase().indexOf(val) !== -1 ||
        d.UserIdParser.toLowerCase().indexOf(val) !== -1 ||
        d.InternalId.toLowerCase().indexOf(val) !== -1 ||
        !val;
    });

    // update the rows
    this.affListData = temp;

    // Whenever the filter changes, always go back to the first page
  }

  getmvpdcountries() {
    this.affiliateService.getmvpdcountries()
      .subscribe(data => {
        this.existingAlias = data;
      }, error => {
        console.error(error);
      });
  }

  getParser() {
    this.affiliateService.getParser()
      .subscribe(data => {
        this.useridParser = data;
      }, error => {
        console.error(error);
      });
  }

  onAffiliateMappingAddClick() {
    const params = {
      existingAlias: this.existingAlias,
      useridParser: this.useridParser
    };

    const results = this.modal.open(AddAffiliateMappingComponent, overlayConfigFactory(params, BSModalContext));
    results.then(data => {
      return data.result.then(e => {
        console.log(e);
      });
    }).catch(error => {
      console.log(error);
    });
  }

  changeRowsOnPage() {
    this.activePage = this.resultTable.activePage;
  }

  OnEditAffiliateMappingClick(id: number) {
    this.modal.open(EditAffiliateMappingComponent, new EditAffiliateMappingContainerWindow());
  }

  OnDeleteAffiliateMappingClick(id: number) {
    const params = {
      data: id,
      onDeleteSelected: this.OnDeleteAffiliateMapping
    };

    const results = this.modal.open(ConfirmDeleteComponent, overlayConfigFactory(params, BSModalContext));
    results.then(data => {
      return data.result.then(e => {
        console.log(e);
      });
    })
      .catch(error => {
        console.log(error);
      });
  }

  OnDeleteAffiliateMapping(id: number) {
    this.affiliateService.deleteAffiliateMapping(id)
      .subscribe(data => {
        console.log(data);
        this.getAffiliatemappings();
      }, error => {
        console.error(error);
      });
  }
}

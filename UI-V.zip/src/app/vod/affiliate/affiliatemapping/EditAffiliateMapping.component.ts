import {Component, OnInit} from '@angular/core';
import {AffiliateService} from '../services/Affiliate.service';
import {Modal, DialogRef, ModalComponent} from 'angular2-modal';
import {BSModalContext} from 'angular2-modal/plugins/bootstrap';
import {FormGroup, FormControl, Validators, FormBuilder} from '@angular/forms';

export class EditAffiliateMappingContainerWindow extends BSModalContext {

}

@Component({
  selector: 'vod-edit-affiliate-mapping',
  templateUrl: './EditAffiliateMapping.component.html'
})
export class EditAffiliateMappingComponent implements OnInit, ModalComponent<EditAffiliateMappingContainerWindow> {
  public affmapping: any;
  context: EditAffiliateMappingContainerWindow;
  editAffiliateMappingForm: FormGroup;
  fb: FormBuilder;

  constructor(private affiliateService: AffiliateService,
              public dialog: DialogRef<EditAffiliateMappingContainerWindow>,
              private modal: Modal) {
    this.context = dialog.context;
    this.context.dialogClass = 'modal-dialog';
    this.context.inElement = true;
    this.context.keyboard = null;
    this.context.isBlocking = true;
    this.context.message = 'Finished';
    this.fb = new FormBuilder();
  }

  ngOnInit(): void {
    this.editAffiliateMappingForm = new FormGroup({
      eventname: new FormControl('New Year Celebrations', Validators.compose([Validators.required, Validators.minLength(6)]))
    });
  }

  close() {
    this.dialog.close();
  }

  EditAffiliateMappingSave() {
    console.log('EditEventSave');
  }
}

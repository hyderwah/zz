import { Component, OnInit } from '@angular/core';
import { AffiliateService } from '../services/Affiliate.service';
import { Modal, DialogRef, ModalComponent } from 'angular2-modal';
import { BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { AffiliateMapping } from '../model/affiliatemapping.model';

export class AddAffiliateMappingContainerWindow extends BSModalContext {
  public existingAlias: any;
  public useridParser: any;
}

@Component({
  selector: 'vod-add-affiliate-mapping',
  templateUrl: './AddAffiliateMapping.component.html'
})
export class AddAffiliateMappingComponent implements OnInit, ModalComponent<AddAffiliateMappingContainerWindow> {
  public affmapping: any;
  public context: AddAffiliateMappingContainerWindow;
  public myForm: FormGroup;
  public fb: FormBuilder;
  existingAlias: any[] = [];
  useridParser: any[] = [];
  affiliates: any[] = [];

  constructor(private affiliateService: AffiliateService,
              public dialog: DialogRef<AddAffiliateMappingContainerWindow>,
              private modal: Modal) {
    this.context = dialog.context;
    this.existingAlias = dialog.context.existingAlias;
    this.useridParser = dialog.context.useridParser;
    this.context.dialogClass = 'modal-dialog';
    this.context.inElement = true;
    this.context.keyboard = null;
    this.context.isBlocking = true;
    this.context.message = 'Finished';
    this.fb = new FormBuilder();
  }

  ngOnInit(): void {
    this.myForm = this.fb.group({
      PrivateKey: ['', []],
      InternalId: ['', []],
      UserIdParser: ['', []],
      MvpdCountryID: ['', []],
      ExistingAlias: ['', []],
      MvpdAlias: ['', []],
      AffiliateMappingId: ['', []],
      Active: [false, []]
    });
  }

  close() {
    this.dialog.close();
  }

  onExistingAliasChange(e: any): void {
    let selectedValue = e.target.value;
    let selectedExistingAlias = this.existingAlias.filter(e => e.Alias === selectedValue)[0];
    this.myForm.patchValue({
      MvpdCountryID: selectedExistingAlias.MvpdCountryID
    });
    let selectedUserIdParser = this.useridParser
  }

  AddAffiliateMappingSave(model: AffiliateMapping, isValid: boolean) {
    console.log('AddEventSave');
  }
}

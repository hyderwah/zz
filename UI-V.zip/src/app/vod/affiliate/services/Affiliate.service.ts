﻿import {Injectable, OnInit} from '@angular/core';
import {Observable} from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';
import {Http, Response, Headers, RequestOptions, URLSearchParams, RequestMethod, Jsonp} from '@angular/http';
import {AppService} from '../../../app.service';
import {ContentReRouteModel} from '../model/contentreroute.model';
import {AffiliateMapping} from '../model/affiliatemapping.model';
import {AffiliatesChannelModel} from '../model/affiliateschannel.model';
import {forkJoin} from 'rxjs/observable/forkJoin';

@Injectable()
export class AffiliateService implements OnInit {

  private actionUrl: string;

  ngOnInit(): void {
    throw new Error('Method not implemented.');
  }

  constructor(private http: Http, private appService: AppService, private jsonp: Jsonp) {
    this.actionUrl = this.appService.apiRootUrl.ApiUrl;
  }

  // Affiliates content reroute

  getContentreroutes(): Observable<any> {
    const headers = new Headers();
    headers.append('content-type', 'application/json');
    return this.http.get(`${this.actionUrl}GetContentReRoute`, {headers: headers})
      .map((response: Response) => <any>response.json());
  }

  getContentreroute(id: string): Observable<any> {
    const headers = new Headers();
    headers.append('content-type', 'application/json');
    return this.http.get(`${this.actionUrl}GetContentReRouteById`, {headers: headers})
      .map((response: Response) => <any>response.json());
  }

  createContentreroute(contentReRoute: ContentReRouteModel): Observable<any> {
    const headers = new Headers();
    headers.append('content-type', 'application/json');
    const body = JSON.stringify(contentReRoute);
    return this.http.post(`${this.actionUrl}CreateContentReRoute`, body, {headers: headers})
      .map((response: Response) => <any>response.json());
  }


  BulkInsert(contentReRoute: any): Observable<any> {
    const headers = new Headers();
    headers.append('content-type', 'application/json');
    const body = JSON.stringify(contentReRoute);
    return this.http.post(`${this.actionUrl}BulkContentReRoute`, body, { headers: headers })
      .map((response: Response) => <any>response.json());
  }


  updateContentreroute(contentReRoute: ContentReRouteModel): Observable<any> {
    const headers = new Headers();
    headers.append('content-type', 'application/json');
    const body = JSON.stringify(contentReRoute);
    return this.http.post(`${this.actionUrl}UpdateContentReRoute`, body, {headers: headers})
      .map((response: Response) => <any>response.json());
  }


  deleteContentreroute(id: number): Observable<any> {
    const headers = new Headers();
    headers.append('content-type', 'application/json');
    return this.http.get(`${this.actionUrl}DeleteContentReRoute?id=${id}`)
      .map((response: Response) => <any>response.json());
  }

  // Affiliate mapping

  getAffiliatemappings(): Observable<any> {
    const headers = new Headers();
    headers.append('content-type', 'application/json');
    return this.http.get(`${this.actionUrl}GetAffiliateMapping`, {headers: headers})
      .map((response: Response) => <any>response.json());
  }

  getAffiliatemapping(id: string): Observable<any> {
    const headers = new Headers();
    headers.append('content-type', 'application/json');
    return this.http.get(`${this.actionUrl}affiliatemappings`, {headers: headers})
      .map((response: Response) => <any>response.json());
  }

  createAffiliatemapping(affiliateMapping: AffiliateMapping): Observable<any> {
    const headers = new Headers();
    headers.append('content-type', 'application/json');
    const body = JSON.stringify(affiliateMapping);
    return this.http.post(`${this.actionUrl}InsertAffiliateMapping`, body, {headers: headers})
      .map((response: Response) => <any>response.json());
  }

  updateAffiliatemapping(affiliateMapping: AffiliateMapping): Observable<any> {
    const headers = new Headers();
    headers.append('content-type', 'application/json');
    const body = JSON.stringify(affiliateMapping);
    return this.http.post(`${this.actionUrl}UpdateAffiliateMapping`, body, {headers: headers})
      .map((response: Response) => <any>response.json());
  }


  deleteAffiliateMapping(id: number): Observable<any> {
    let headers = new Headers();
    headers.append('content-type', 'application/json');
    return this.http.get(`${this.actionUrl}DeleteAffiliateMapping?id=${id}`)
      .map((response: Response) => <any>response.json());
  }

  //getMvpdCountrys(): Observable<any> {
  //  const headers = new Headers();
  //  headers.append('content-type', 'application/json');
  //  return this.http.get(`${this.actionUrl}GetMvpdcountries`, { headers: headers })
  //    .map((response: Response) => <any>response.json());
  //}

  //Affiliate Channels

  getAffiliateschannels(): Observable<any> {
    const headers = new Headers();
    headers.append('content-type', 'application/json');
    return this.http.get(`${this.actionUrl}GetAffiliateChannels`, {headers: headers})
      .map((response: Response) => <any>response.json());
  }

  getAffiliateschannel(id: string): Observable<any> {
    const headers = new Headers();
    headers.append('content-type', 'application/json');
    return this.http.get(`${this.actionUrl}GetAffiliatesChannelById`, {headers: headers})
      .map((response: Response) => <any>response.json());
  }

  createAffiliateschannel(affiliatesChannel: AffiliatesChannelModel): Observable<any> {
    const headers = new Headers();
    headers.append('content-type', 'application/json');
    const body = JSON.stringify(affiliatesChannel);
    return this.http.post(`${this.actionUrl}CreateAffiliatesChannel`, body, {headers: headers})
      .map((response: Response) => <any>response.json());
  }

  updateAffiliateschannel(affiliatesChannel: AffiliatesChannelModel): Observable<any> {
    const headers = new Headers();
    headers.append('content-type', 'application/json');
    const body = JSON.stringify(affiliatesChannel);
    return this.http.post(`${this.actionUrl}UpsertAffiliatesChannel`, body, {headers: headers})
      .map((response: Response) => <any>response.json());
  }

  deleteAffiliatesChannel(id: number): Observable<any> {
    let headers = new Headers();
    headers.append('content-type', 'application/json');
    return this.http.get(`${this.actionUrl}DeleteAffiliatesChannel?id=${id}`)
      .map((response: Response) => <any>response.json());
  }

  // getcountrys

  getCountrys(): Observable<any> {
    const headers = new Headers();
    headers.append('content-type', 'application/json');
    return this.http.get(`${this.actionUrl}Getcountrys`, { headers: headers })
      .map((response: Response) => <any>response.json());
  }

  // getparser

  getParser(): Observable<any> {
    const headers = new Headers();
    headers.append('content-type', 'application/json');
    return this.http.get(`${this.actionUrl}GetAffiliatesParsers`, { headers: headers })
      .map((response: Response) => <any>response.json());
  }

  // get channels
  getChannels(): Observable<any> {
    const headers = new Headers();
    headers.append('content-type', 'application/json');
    return this.http.get(`${this.actionUrl}GetChannels`, {headers: headers})
      .map((response: Response) => <any>response.json());
  }

  // get affliates
  getAffiliates(): Observable<any> {
    const headers = new Headers();
    headers.append('content-type', 'application/json');
    return this.http.get(`${this.actionUrl}GetAffiliateAlias`, {headers: headers})
      .map((response: Response) => <any>response.json());
  }

  // get mvpdcountries
  getmvpdcountries(): Observable<any> {
    const headers = new Headers();
    headers.append('content-type', 'application/json');
    return this.http.get(`${this.actionUrl}GetMvpdcountries`, {headers: headers})
      .map((response: Response) => <any>response.json());
  }

  //get Authzdrequests

  getAuthzdrequests(): Observable<any> {
    const headers = new Headers();
    headers.append('content-type', 'application/json');
    return this.http.get(`${this.actionUrl}Authzdrequests`, { headers: headers })
      .map((response: Response) => <any>response.json());
  }

  getAffiliateChannelObjects(id: string, callback: (any) => void): any {
    const _id = Number(id);
    const headers = new Headers();
    headers.append('content-type', 'application/json');
    const channels = this.http.get(`${this.actionUrl}GetChannels`, {headers: headers});
    const affiliates = this.http.get(`${this.actionUrl}GetAffiliateAlias`, {headers: headers});
    forkJoin([channels, affiliates]).subscribe(results => {
      callback(results);
    });
  }

  getAffiliateContentRerouteObjects(id: string, callback: (any) => void): any {
    const _id = Number(id);
    const headers = new Headers();
    headers.append('content-type', 'application/json');
    const channels = this.http.get(`${this.actionUrl}GetChannels`, {headers: headers});
    const affiliates = this.http.get(`${this.actionUrl}GetAffiliateAlias`, {headers: headers});
    const affiliatechannel = this.http.get(`${this.actionUrl}GetContentReRouteById?id=${_id}`, {headers: headers});
    forkJoin([channels, affiliates, affiliatechannel]).subscribe(results => {
      callback(results);
    });
  }
}

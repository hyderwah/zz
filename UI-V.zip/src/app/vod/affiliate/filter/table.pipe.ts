﻿import {Pipe, PipeTransform} from "@angular/core";

@Pipe({
    name: "dataFilter"
})
export class DataFilterPipe implements PipeTransform {
    
    transform(array: any[], query: string): any {
        var result: any = array;
        if (array && query) {
            var filterkeys = Object.keys(result);
            result = result.filter((item: any) =>
                (item.DisplayName != null ? item.DisplayName.indexOf(query) > -1 : 0)
                ||
                (item.CountryName != null ? item.CountryName.indexOf(query) > -1 : 0)
                ||
                (item.OwnerName != null ? item.OwnerName.indexOf(query) > -1 : 0)
                ||
                (item.CreatedOn != null ? item.CreatedOn.indexOf(query) > -1 : 0)
                ||
                (item.StatusName != null ? item.StatusName.indexOf(query) > -1 : 0)
                


            );
           
        }
     
        return result;
    }
}
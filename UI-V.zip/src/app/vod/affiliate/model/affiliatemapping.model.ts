export interface AffiliateMapping {

}
export class AffiliatesChannelModel {
    AffiliateChannelId: number;
    AffiliateMappingId?: number;
    ChannelId?: number;
    Active?: number;
    BypassRights?: number;
    EnforceAuthZ?: number;
    CreatedOn?: string;
    CreatedBy?: string;
    msrepl_tran_version?: string;
    ReRoute?: number;
    ReRouteByContent?: number;
}
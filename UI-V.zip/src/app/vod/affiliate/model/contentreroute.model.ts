export class ContentReRouteModel {
  AffiliatesContentReRouteID: number;
  ReRoute?: number;
  HouseID: string;
  AffiliateChannelId: number;
  ChannelName: string;
  ExistingAlias: string;
}
import {Component, OnInit} from '@angular/core';
import {AffiliateService} from '../services/Affiliate.service';
import {Modal, DialogRef, ModalComponent} from 'angular2-modal';
import {BSModalContext} from 'angular2-modal/plugins/bootstrap';
import {FormGroup, FormControl, Validators, FormBuilder} from '@angular/forms';
import {AffiliatesChannelModel} from '../model/affiliateschannel.model';

export class AddAffiliateChannelContainerWindow extends BSModalContext {
  public data: any;
  public channelList: any;
  public affiliateList: any;
  public getAffiliatesChannels: any;
}

@Component({
  selector: 'vod-add-affiliate-channel',
  templateUrl: './AddAffiliateChannel.component.html'
})
export class AddAffiliateChannelComponent implements OnInit, ModalComponent<AddAffiliateChannelContainerWindow> {
  public affchannel: any;
  context: AddAffiliateChannelContainerWindow;
  public myForm: FormGroup;
  public submitted: boolean;
  public events: any[] = [];
  acm: AffiliatesChannelModel;
  affiliates: any[] = [];
  channels: any[] = [];
  public getAffiliatesChannels: any;

  constructor(private affiliateService: AffiliateService,
              public dialog: DialogRef<AddAffiliateChannelContainerWindow>,
              private modal: Modal,
              private fb: FormBuilder) {
    this.context = dialog.context;
    this.channels = dialog.context.channelList;
    this.affiliates = dialog.context.affiliateList;
    this.getAffiliatesChannels = dialog.context.getAffiliatesChannels;
    this.context.dialogClass = 'modal-dialog';
    this.context.inElement = true;
    this.context.keyboard = null;
    this.context.isBlocking = true;
    this.context.message = 'Finished';
    this.fb = new FormBuilder();
    this.acm = new AffiliatesChannelModel();
  }

  ngOnInit(): void {

    this.myForm = this.fb.group({
      ChannelId: [0, [<any>Validators.required]],
      AffiliateMappingId: [0, [<any>Validators.required]],
      BypassRights: [false, []],
      EnforceAuthZ: [false, []],
      ReRoute: [false, []],
      ReRouteByContent: [false, []],
      Active: [false, []]
    });
    this.submitted = false;
    // common for all componenets 
    this.subcribeToFormChanges();

    (<FormControl>this.myForm.controls['AffiliateMappingId']).setValue(0, {onlySelf: true});
  }

  close() {
    this.dialog.close();
  }

  AddAffiliateChannel(model: AffiliatesChannelModel, isValid: boolean) {
    model['Active'] = model['Active'] ? 1 : 0;
    model['BypassRights'] = model['BypassRights'] ? 1 : 0;
    model['EnforceAuthZ'] = model['EnforceAuthZ'] ? 1 : 0;
    model['ReRoute'] = model['ReRoute'] ? 1 : 0;
    model['ReRouteByContent'] = model['ReRouteByContent'] ? 1 : 0;
    this.affiliateService.createAffiliateschannel(model).subscribe(
      data => {
        if (data) {
          this.submitted = true;
          this.dialog.close();
          this.getAffiliatesChannels();
        } else {
          alert('Fail');
        }
      },
      error => {
        alert(error);
      }
    );
  }

  subcribeToFormChanges() {
    const myFormStatusChanges = this.myForm.statusChanges;
    const myFormValueChanges = this.myForm.valueChanges;
    myFormStatusChanges.subscribe(x => this.events.push({event: 'STATUS_CHANGED', object: x}));
    myFormValueChanges.subscribe(y => this.events.push({event: 'VALUE_CHANGED', object: y}));
  }
}

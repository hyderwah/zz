import {Component, OnInit} from '@angular/core';
import {AffiliateService} from '../services/Affiliate.service';
// import { Modal, DialogRef, ModalComponent } from 'ngx-modialog';
// import { BSModalContext } from 'ngx-modialog/plugins/bootstrap';
import {Modal, DialogRef, ModalComponent} from 'angular2-modal';
import {BSModalContext} from 'angular2-modal/plugins/bootstrap';
import {FormGroup, FormControl, Validators, FormBuilder} from '@angular/forms';
import {forkJoin} from 'rxjs/observable/forkJoin';
import {AffiliatesChannelModel} from '../model/affiliateschannel.model';


export class EditAffiliateChannelContainerWindow extends BSModalContext {
  public data: any;
  public affiliateChannel: any;
  public channelList: any[];
  public affiliateList: any[];
  public getAffiliatesChannels: any;
}

@Component({
  selector: 'vod-edit-affiliate-channel',
  templateUrl: './EditAffiliateChannel.component.html'
})
export class EditAffiliateChannelComponent implements OnInit, ModalComponent<EditAffiliateChannelContainerWindow> {
  public myForm: FormGroup;
  public submitted: boolean;
  public events: any[] = [];
  context: EditAffiliateChannelContainerWindow;
  editAffiliateChannelForm: FormGroup;
  fb: FormBuilder;
  id: any;
  affiliateChannel: any;
  affiliates: any[] = [];
  channels: any[] = [];
  public affchannel: any;
  public getAffiliatesChannels: any;

  constructor(private affiliateService: AffiliateService,
              public dialog: DialogRef<EditAffiliateChannelContainerWindow>,
              private modal: Modal) {
    this.id = dialog.context.data;
    this.affiliateChannel = dialog.context.affiliateChannel;
    this.channels = dialog.context.channelList;
    this.affiliates = dialog.context.affiliateList;
    this.getAffiliatesChannels = dialog.context.getAffiliatesChannels;
    this.context = dialog.context;
    this.context.dialogClass = 'modal-dialog';
    this.context.inElement = true;
    this.context.keyboard = null;
    this.context.isBlocking = true;
    this.context.message = 'Finished';
    this.fb = new FormBuilder();
  }

  ngOnInit(): void {

    this.myForm = this.fb.group({
      AffiliateChannelId: [0],
      ChannelId: [0, [<any>Validators.required]],
      AffiliateMappingId: [0, [<any>Validators.required]],
      Active: [false, []],
      BypassRights: [false, []],
      EnforceAuthZ: [false, []],
      ReRoute: [false, []],
      ReRouteByContent: [false, []]

    });
    this.submitted = false;
    // common for all componenets
    this.subcribeToFormChanges();

    this.myForm.setValue({
      AffiliateChannelId: this.affiliateChannel.AffiliateChannelId,
      ChannelId: this.affiliateChannel.ChannelId,
      AffiliateMappingId: this.affiliateChannel.AffiliateMappingId,
      BypassRights: this.affiliateChannel.BypassRights === 1,
      EnforceAuthZ: this.affiliateChannel.EnforceAuthZ === 1,
      ReRoute: this.affiliateChannel.ReRoute === 1,
      ReRouteByContent: this.affiliateChannel.ReRouteByContent === 1,
      Active: this.affiliateChannel.Active === 1,
    });
  }

  close() {
    this.dialog.dismiss();
  }

  EditAffiliateChannelSave(model: AffiliatesChannelModel, isValid: boolean) {
    model['Active'] = model['Active'] ? 1 : 0;
    model['BypassRights'] = model['BypassRights'] ? 1 : 0;
    model['EnforceAuthZ'] = model['EnforceAuthZ'] ? 1 : 0;
    model['ReRoute'] = model['ReRoute'] ? 1 : 0;
    model['ReRouteByContent'] = model['ReRouteByContent'] ? 1 : 0;
    model['ChannelId'] = Number(model['ChannelId']);
    model['AffiliateMappingId'] = Number(model['AffiliateMappingId']);
    this.affiliateService.updateAffiliateschannel(model).subscribe(
      data => {
        if (data) {
          this.submitted = true;
          this.dialog.close(true);
          this.getAffiliatesChannels();
        } else {
          this.dialog.close(false);
        }
      },
      error => {
        console.error(error);
      }
    );
  }


  subcribeToFormChanges() {
    const myFormStatusChanges = this.myForm.statusChanges;
    const myFormValueChanges = this.myForm.valueChanges;

    myFormStatusChanges.subscribe(x => this.events.push({event: 'STATUS_CHANGED', object: x}));
    myFormValueChanges.subscribe(y => this.events.push({event: 'VALUE_CHANGED', object: y}));
  }
}

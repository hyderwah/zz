﻿import { Component, OnInit, ViewContainerRef, Optional, ViewEncapsulation, ViewChild} from '@angular/core';
import {AffiliateService} from '../services/Affiliate.service';
import {overlayConfigFactory} from 'angular2-modal';
import {Modal, BSModalContext} from 'angular2-modal/plugins/bootstrap';
import {ActivatedRoute, Router} from '@angular/router';
import {AddAffiliateChannelComponent} from './AddAffiliateChannel.component';
import {EditAffiliateChannelComponent} from './EditAffiliateChannel.component';
import {ConfirmDeleteComponent} from '../shared/ConfirmDelete.component';
import { DataTable } from 'angular2-datatable';

@Component({
  selector: 'vod-affiliate-channel',
  templateUrl: './AffiliateChannel.component.html'
})
export class AffiliateChannelComponent implements OnInit {
  @ViewChild(DataTable) resultTable: DataTable;
  

  public existingAlias: string;
  public afflist: any[] = [];
  public affListData: any[];
  public searchText: string;
  public channelList: any[];
  public affiliateList: any[];
  public rowsOnPage: number = 10;
  public filterQuery = '';
  public sortBy = '';
  public sortOrder = 'desc';
  public currentUser: any;
  public activePage: number = 1;


  constructor(private affiliateService: AffiliateService, public modal: Modal,
              vcRef: ViewContainerRef, public _activatedRoute: ActivatedRoute) {
    this.affListData = [...this.afflist];
    this.currentUser = JSON.parse(localStorage.getItem('currentUser'));
  }

  ngOnInit(): void {
    this._activatedRoute.params.subscribe((params) => {
      this.existingAlias = params['existingAlias'];
      this.getAffiliatesChannels(this.existingAlias);
    });
    this.getChannels();
    this.getAffiliates();
  }

  getAffiliatesChannels(existingAlias: string) {
    this.affiliateService.getAffiliateschannels()
      .subscribe(data => {
        this.afflist = [];
        let affiliateData = data;
        if (existingAlias) {
          affiliateData = data.filter(function (d) {
            return d.AffiliateMappingName.toLowerCase().indexOf(existingAlias) !== -1;
          });
        }

        this.afflist = affiliateData;
        this.affListData = affiliateData;
      }, error => {
        console.error(error);
      });
  }

  getChannels() {
    this.affiliateService.getChannels()
      .subscribe(data => {
        this.channelList = data;
      }, error => {
        console.error(error);
      });
  }

  getAffiliates() {
    this.affiliateService.getAffiliates()
      .subscribe(data => {
        this.affiliateList = data;
      }, error => {
        console.error(error);
      });
  }

  updateFilter(event) {
    const val = event.target.value.toLowerCase();
    this.searchText = val;
    // filter our data

    const temp = this.afflist.filter(function (d) {
      return d.AffiliateMappingName.toLowerCase().indexOf(val) !== -1 ||
        d.ChannelName.toLowerCase().indexOf(val) !== -1 ||
        d.CountryName.toLowerCase().indexOf(val) !== -1 ||
        !val;
    });

    // update the rows
    this.affListData = temp;
  }

  fileChange(event) {
    const fileList: FileList = event.target.files;
    if (fileList.length > 0) {
      const file: File = fileList[0];
      const formData: FormData = new FormData();
      formData.append('uploadFile', file, file.name);
    }
  }

  changeRowsOnPage() {
    this.activePage = this.resultTable.activePage;
  }


  onAffiliateChannelCreateClick() {

    const params = {
      channelList: this.channelList,
      affiliateList: this.affiliateList,
      getAffiliatesChannels: this.getAffiliatesChannels
    };

    const results = this.modal.open(AddAffiliateChannelComponent, overlayConfigFactory(params, BSModalContext));
    results.then(data => {
      return data.result.then(e => {
        console.log(e);
      });
    }).catch(error => {
      console.log(error);
    });
  }

  OnEditAffiliateChannelClick(id: number) {
    const selectedChannel = this.afflist.filter(e => e.AffiliateChannelId === id)[0];

    const params = {
      data: id,
      affiliateChannel: selectedChannel,
      channelList: this.channelList,
      affiliateList: this.affiliateList,
      getAffiliatesChannels: this.getAffiliatesChannels
    };
    const results = this.modal.open(EditAffiliateChannelComponent, overlayConfigFactory(params, BSModalContext));
    results.then(data => {
      return data.result.then(e => {
        console.log(e);
      });
    })
      .catch(error => {
        console.log(error);
      });
  }

  OnDeleteAffiliateChannelClick(id: number) {
    const params = {
      data: id,
      onDeleteSelected: this.onDeleteAffiliateChannel.bind(this)
    };

    const results = this.modal.open(ConfirmDeleteComponent, overlayConfigFactory(params, BSModalContext));
    results.then(data => {
      return data.result.then(e => {
        console.log(e);
      });
    })
      .catch(error => {
        console.log(error);
      });
  }

  onDeleteAffiliateChannel(id: number) {
    this.affiliateService.deleteAffiliatesChannel(id)
      .subscribe(data => {
        console.log(data);

        this.getAffiliatesChannels(this.existingAlias);
      }, error => {
        console.error(error);
      });
  }
}

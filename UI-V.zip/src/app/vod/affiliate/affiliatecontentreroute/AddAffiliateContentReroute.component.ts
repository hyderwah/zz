import {Component, OnInit} from '@angular/core';
import {AffiliateService} from '../services/Affiliate.service';
import {BSModalContext} from 'angular2-modal/plugins/bootstrap';
import {Modal, DialogRef, ModalComponent} from 'angular2-modal';
import {FormGroup, FormControl, Validators, FormBuilder} from '@angular/forms';
import {ContentReRouteModel} from '../model/contentreroute.model';

export class AddAffiliateContentRerouteContainerWindow extends BSModalContext {
  public data: any;
  public channelList: any[];
  public affiliateList: any[];
  public getContentreroutes: any;
}

@Component({
  selector: 'vod-add-affiliate-content-reroute',
  templateUrl: './AddAffiliateContentReroute.component.html'
})
export class AddAffiliateContentRerouteComponent implements OnInit, ModalComponent<AddAffiliateContentRerouteContainerWindow> {
  public affcontentreroute: any;
  context: AddAffiliateContentRerouteContainerWindow;
  public myForm: FormGroup;
  public submitted: boolean;
  public events: any[] = [];
  arr: ContentReRouteModel;
  affiliates: any[] = [];
  channels: any[] = [];
  public getContentreroutes: any;

  constructor(private affiliateService: AffiliateService,
              public dialog: DialogRef<AddAffiliateContentRerouteContainerWindow>,
              private modal: Modal,
              private fb: FormBuilder) {
    this.context = dialog.context;
    this.affiliates = dialog.context.affiliateList;
    this.channels = dialog.context.channelList;
    this.getContentreroutes = dialog.context.getContentreroutes;
    this.context.dialogClass = 'modal-dialog';
    this.context.inElement = true;
    this.context.keyboard = null;
    this.context.isBlocking = true;
    this.context.message = 'Finished';
    this.fb = new FormBuilder();
    this.arr = new ContentReRouteModel();
  }

  ngOnInit(): void {

    this.myForm = this.fb.group({
      ChannelId: [0, [<any>Validators.required]],
      AffiliateMappingId: [0, [<any>Validators.required]],
      ReRoute: ['', []],
      HouseId: ['', []],
      AffiliateChannelId: ['', []],
    });
    this.submitted = false;
    this.subcribeToFormChanges();
    (<FormControl>this.myForm.controls['AffiliateMappingId']).setValue(0, {onlySelf: true});
  }

  close() {
    this.dialog.close();
  }

  addContentRerouteSave(model: ContentReRouteModel, isValid: boolean) {
    model['ReRoute'] = model['ReRoute'] ? 1 : 0;

    this.affiliateService.createContentreroute(model).subscribe(
      data => {
        if (data) {
          this.submitted = true;
          this.dialog.close();
          this.getContentreroutes();
        } else {
          alert('Fail');
        }
      },
      error => {alert(error);
   });
  }

  subcribeToFormChanges() {
    const myFormStatusChanges = this.myForm.statusChanges;
    const myFormValueChanges = this.myForm.valueChanges;
    myFormStatusChanges.subscribe(x => this.events.push({event: 'STATUS_CHANGED', object: x}));
    myFormValueChanges.subscribe(y => this.events.push({event: 'VALUE_CHANGED', object: y}));
  }
}

﻿import { Component, OnInit, ViewContainerRef, ViewEncapsulation, ViewChild} from '@angular/core';
import {AffiliateService} from '../services/Affiliate.service';
import {AddAffiliateContentRerouteComponent} from './AddAffiliateContentReroute.component';
import {EditAffiliateContentRerouteComponent} from './EditAffiliateContentReroute.component';
import {ActivatedRoute, Router} from '@angular/router';
import {overlayConfigFactory} from 'angular2-modal';
import {Modal, BSModalContext} from 'angular2-modal/plugins/bootstrap';
import { ConfirmDeleteComponent } from '../shared/ConfirmDelete.component';
import { DataTable } from 'angular2-datatable';


@Component({
  selector: 'vod-affiliate-content-reroute',
  templateUrl: './AffiliateContentReroute.component.html',
  styleUrls: ['./AffiliateContentReroute.component.css']
})
export class AffiliateContentRerouteComponent implements OnInit {
  @ViewChild(DataTable) resultTable: DataTable;

  public afflist: any[] = [];
  public affListData: any[];
  public channelList: any[];
  public affiliateList: any[];
  public searchText: string;
  public affiliateChannelId: string;
  public rowsOnPage: number = 10;
  public activePage: number = 1;
  public filterQuery = '';
  public sortBy = '';
  public sortOrder = 'desc';
  public fileReader: any;
  public contentReRouteBulkList: any[];
  public currentUser: any;

  constructor(private affiliateService: AffiliateService, public modal: Modal,
              public _activatedRoute: ActivatedRoute) {
    this.affListData = [...this.afflist];
    this.currentUser = JSON.parse(localStorage.getItem('currentUser'));
  }

  ngOnInit(): void {
    this._activatedRoute.params.subscribe((params) => {
      this.affiliateChannelId = params['affiliateChannelId'];
      this.getContentreroutes();
    });

    // this.getContentreroutes();
    this.getAffiliates();
    this.getChannels();
  }

  getContentreroutes() {
    this.affiliateService.getContentreroutes()
      .subscribe(data => {
        this.afflist = [];
        let affiliateContentReRouteData = data;
        if (this.affiliateChannelId) {
          affiliateContentReRouteData = data.filter(e => e.AffiliateChannelId === parseInt(this.affiliateChannelId));
        }
        this.afflist = affiliateContentReRouteData;
        this.affListData = affiliateContentReRouteData;
      }, error => {
        console.error(error);
      });
  }

  getChannels() {
    this.affiliateService.getChannels()
      .subscribe(data => {
        this.channelList = data;
      }, error => {
        console.error(error);
      });
  }

  getAffiliates() {
    this.affiliateService.getAffiliates()
      .subscribe(data => {
        this.affiliateList = data;
      }, error => {
        console.error(error);
      });
  }

  changeRowsOnPage() {
    this.activePage = this.resultTable.activePage;
  }

  updateFilter(event) {
    const val = event.target.value.toLowerCase();
    this.searchText = val;
    // filter our data

    const temp = this.afflist.filter(function (d) {
      return d.HouseID.toLowerCase().indexOf(val) !== -1 ||
        d.ExistingAlias.toLowerCase().indexOf(val) !== -1 ||
        d.ChannelName.toLowerCase().indexOf(val) !== -1 ||
        !val;
    });
    // update the rows
    this.affListData = temp;
  }

  onAffiliateContentRerouteCreateClick() {
    const params = {
      channelList: this.channelList,
      affiliateList: this.affiliateList,
      getContentreroutes: this.getContentreroutes
    };

    const results = this.modal.open(AddAffiliateContentRerouteComponent,
      overlayConfigFactory(params, BSModalContext));

  }

  OnEditAffiliateContentRerouteClick(id: number) {
    const selected = this.afflist.filter(e => e.AffiliatesContentReRouteID === id)[0];

    const params = {
      data: id,
      affiliateContentReRoute: selected,
      channelList: this.channelList,
      affiliateList: this.affiliateList,
      getContentreroutes: this.getContentreroutes
    };
    const results = this.modal.open(EditAffiliateContentRerouteComponent, overlayConfigFactory(params, BSModalContext));
    results.then(data => {
      return data.result.then(e => {
        // console.log(e);
      });
    })
      .catch(error => {
        console.log(error);
      });
  }

  onBulkSave() {
    if (this.contentReRouteBulkList.length > 0) {
      this.affiliateService.BulkInsert(this.contentReRouteBulkList).subscribe(data => {
        console.log(data);
        this.getContentreroutes();
      }, error => {
        console.error(error);
      });
    } else {
      alert('There is no data to save');
    }
  }

  onDeleteClick() {
    this.fileReader = null;
    this.contentReRouteBulkList = [];
  }

  OnDeleteAffiliateContentRerouteClick(id: number) {
    const params = {
      data: id,
      onDeleteSelected: this.OnDeleteAffiliateContentReroute.bind(this)
    };

    const results = this.modal.open(ConfirmDeleteComponent, overlayConfigFactory(params, BSModalContext));
    results.then(data => {
      return data.result.then(e => {
        console.log(e);
      });
    })
      .catch(error => {
        console.log(error);
      });
  }

  OnDeleteAffiliateContentReroute(id: number) {
    this.affiliateService.deleteContentreroute(id)
      .subscribe(data => {
        console.log(data);
        this.getContentreroutes();
      }, error => {
        console.error(error);
      });
  }

  getFiles(file: any) {
    debugger;
    this.fileReader = file.target.files[0];
    const reader: FileReader = new FileReader();
    reader.readAsText(this.fileReader);

    reader.onload = (e) => {
      const csv: string = reader.result;
      const allTextLines = csv.split(/\r|\n|\r/);
      const headers = allTextLines[0].split(',');
      const lines = [], contentReRouteList = [];
      let contentReRoute = {};

      for (let i = 1; i < allTextLines.length; i++) {
        if (allTextLines[i].replace(/,/g, '').trim() !== '' && allTextLines[i].trim().length > 0) {
          const data = allTextLines[i].split(',');
          contentReRoute = {};
          contentReRoute['HouseId'] = data[0];
          contentReRoute['ReRoute'] = parseInt(data[1]);
          contentReRoute['AffiliateChannelId'] = parseInt(data[2]);

          contentReRouteList.push(contentReRoute);
        }
      }
      this.contentReRouteBulkList = contentReRouteList;
    };
  }
}

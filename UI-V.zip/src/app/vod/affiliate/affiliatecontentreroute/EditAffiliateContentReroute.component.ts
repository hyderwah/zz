import {Component, OnInit} from '@angular/core';
import {AffiliateService} from '../services/Affiliate.service';
import {Modal, DialogRef, ModalComponent} from 'angular2-modal';
import {BSModalContext} from 'angular2-modal/plugins/bootstrap';
import {FormGroup, FormControl, Validators, FormBuilder} from '@angular/forms';
import {forkJoin} from 'rxjs/observable/forkJoin';
import {ContentReRouteModel} from '../model/contentreroute.model';

export class EditAffiliateContentRerouteContainerWindow extends BSModalContext {
  public data: any;
  public affiliateContentReRoute: any;
  public channelList: any[];
  public affiliateList: any[];
  public getContentreroutes: any;
}

@Component({
  selector: 'vod-edit-affiliate-content-reroute',
  templateUrl: './EditAffiliateContentReroute.component.html'
})
export class EditAffiliateContentRerouteComponent implements OnInit, ModalComponent<EditAffiliateContentRerouteContainerWindow> {
  public myForm: FormGroup;
  public affcontentreroute: any;
  public submitted: boolean;
  public events: any[] = [];
  context: EditAffiliateContentRerouteContainerWindow;
  editAffiliateContentRerouteForm: FormGroup;
  fb: FormBuilder;
  id: any;
  affiliateContentReRoute: any;
  affiliates: any[] = [];
  channels: any[] = [];
  public contentreroute: any;
  public getContentreroutes: any;

  constructor(private affiliateService: AffiliateService,
              public dialog: DialogRef<EditAffiliateContentRerouteContainerWindow>,
              private modal: Modal) {
    this.id = dialog.context.data;
    this.affiliateContentReRoute = dialog.context.affiliateContentReRoute;
    this.affiliates = dialog.context.affiliateList;
    this.channels = dialog.context.channelList;
    this.getContentreroutes = dialog.context.getContentreroutes;
    this.context = dialog.context;
    this.context.dialogClass = 'modal-dialog';
    this.context.inElement = true;
    this.context.keyboard = null;
    this.context.isBlocking = true;
    this.context.message = 'Finished';
    this.fb = new FormBuilder();
  }

  ngOnInit(): void {

    this.myForm = this.fb.group({
      ContentReRouteID: [0],
      ChannelId: [0, [<any>Validators.required]],
      AffiliateMappingId: [0, [<any>Validators.required]],
      ReRoute: [false, []],
      HouseId: ['', []],
    });

    const affiliate = this.affiliates.filter(e => e.ExistingAlias === this.affiliateContentReRoute.ExistingAlias)[0];
    const channel = this.channels.filter(e => e.ChannelName === this.affiliateContentReRoute.ChannelName)[0];

    this.myForm.setValue({
      ContentReRouteID: this.affiliateContentReRoute.AffiliatesContentReRouteID,
      ChannelId: channel ? channel.ChannelID : '',
      AffiliateMappingId: affiliate ? affiliate.AffiliatesMappingID : '',
      HouseId: this.affiliateContentReRoute.HouseID,
      ReRoute: this.affiliateContentReRoute.ReRoute === 1,
    });

    this.submitted = false;
    // common for all componenets
    this.subcribeToFormChanges();
  }

  close() {
    this.dialog.close();
  }

  EditAffiliateContentRerouteSave(model: ContentReRouteModel, isValid: boolean) {
    model['ReRoute'] = model['ReRoute'] ? 1 : 0;
    this.affiliateService.updateContentreroute(model).subscribe(data => {
        if (data) {
          this.submitted = true;
          this.dialog.close(true);
          this.getContentreroutes();
        } else {
          this.dialog.close(false);
        }
      },
      error => {
        console.error(error);
      });
  }

  subcribeToFormChanges() {
    const myFormStatusChanges = this.myForm.statusChanges;
    const myFormValueChanges = this.myForm.valueChanges;

    myFormStatusChanges.subscribe(x => this.events.push({event: 'STATUS_CHANGED', object: x}));
    myFormValueChanges.subscribe(y => this.events.push({event: 'VALUE_CHANGED', object: y}));
  }
}

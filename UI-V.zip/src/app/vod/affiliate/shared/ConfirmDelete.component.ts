import {Component, OnInit} from '@angular/core';
import {Modal, DialogRef, ModalComponent} from 'angular2-modal';
import {BSModalContext} from 'angular2-modal/plugins/bootstrap';

export class ConfirmDeleteContainerWindow extends BSModalContext {
  public data: any;
  public onDeleteSelected: any;
}

@Component({
  selector: 'vod-delete-confirm',
  templateUrl: './ConfirmDelete.component.html'
})

export class ConfirmDeleteComponent implements OnInit, ModalComponent<ConfirmDeleteContainerWindow> {
  public submitted: boolean;
  public events: any[] = [];
  context: ConfirmDeleteContainerWindow;
  id: any;
  public onDeleteSelected: any;

  constructor(public dialog: DialogRef<ConfirmDeleteContainerWindow>,
              private modal: Modal) {
    this.id = dialog.context.data;
    this.onDeleteSelected = dialog.context.onDeleteSelected;
    this.context = dialog.context;
    this.context.dialogClass = 'modal-dialog';
    this.context.inElement = true;
    this.context.keyboard = null;
    this.context.isBlocking = true;
    this.context.message = 'Finished';
  }

  ngOnInit(): void {

  }

  onYesClick(): void {
    this.onDeleteSelected(this.id);
    this.dialog.close(true);
  }

  onNoClick(): void {
    this.dialog.close(true);
  }

}

import {BrowserModule} from '@angular/platform-browser';
import {NgModule, CUSTOM_ELEMENTS_SCHEMA, APP_INITIALIZER} from '@angular/core';
import {HttpClientModule} from '@angular/common/http';
import {HttpModule, JsonpModule} from '@angular/http';
import { RouterModule, Routes} from '@angular/router';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import { DataTableModule, PageEvent } from 'angular2-datatable';
//import { NG2DataTableModule } from "angular2-datatable-pagination";
import { HashLocationStrategy, LocationStrategy } from '@angular/common';
import {AuthGuard} from './guard/index';

import {AppService} from './app.service';
import {Routing} from './app.route';
import {AppComponent} from './app.component';
import {AccountModule} from './account/account.module';
import {VodModule} from './vod/vod.module';

import {AffiliateService} from './vod/affiliate/services/Affiliate.service';
import {AuthService} from './account/services/auth.service';

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    Routing,
    VodModule,
    AccountModule,
    BrowserModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule,
    DataTableModule,
    //NG2DataTableModule,
    HttpModule,
    JsonpModule
  ],
  providers: [
    // RouterOutletMap,
    AuthGuard,
    AppService,
    AffiliateService,
    AuthService,
    {provide: LocationStrategy, useClass: HashLocationStrategy}
    // { provide: APP_INITIALIZER, useFactory: initAppSettings, deps: [AppService], multi: true }
  ],
  bootstrap: [AppComponent]
})
export class AppModule {
}

// export function initAppSettings(config: AppService) {
//   return () => config.readAppSettings();
// }

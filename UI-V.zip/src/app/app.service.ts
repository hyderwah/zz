import {Injectable, OnInit} from '@angular/core';
import {Observable} from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';
import {Http, Response, Headers, RequestOptions, URLSearchParams, RequestMethod} from '@angular/http';
import {environment} from '../environments/environment';

@Injectable()

export class AppService implements OnInit {

  userrole: string;
  username: string;
  apirooturl: any;

  constructor(private http: Http) {
    this.apiRootUrl = environment;
  }

  internalAuthentication(): Observable<any> {
    const headers = new Headers();
    headers.append('content-type', 'application/x-www-form-urlencoded');
    return this.http.get(this.apiRootUrl.ApiUrl + '/Services/', {
      headers: headers,
      withCredentials: true
    })
      .map(res => res.json());

  }

  get userRole(): string {
    return this.userrole;
  }

  set userRole(value: string) {
    this.userrole = value;

  }

  get userName(): string {
    return this.username;
  }

  set userName(value: string) {
    this.username = value;

  }

  get apiRootUrl(): any {
    return this.apirooturl;
  }

  set apiRootUrl(value: any) {
    this.apirooturl = value;

  }

  ngOnInit() {

  }

}

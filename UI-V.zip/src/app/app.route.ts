import { Routes, RouterModule } from '@angular/router';
import { ModuleWithProviders } from '@angular/core';

import {VodRoutes} from './vod/vod.routes';
import { AccountRoutes } from './account/account.routes';


// const MASTERROUTES: Routes = [
//
//   {
//     path: 'master',
//     loadChildren: 'src/app/master/vod.module#VodModule'
//
//   }
// ];
const ROUTES: Routes = [
  ...AccountRoutes,
  ...VodRoutes,
];

export const Routing: ModuleWithProviders = RouterModule.forRoot(ROUTES);

